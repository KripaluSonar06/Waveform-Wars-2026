# 🎵 Audio Source Separation using Pure DSP (No ML)

A **classical Digital Signal Processing (DSP)** based implementation for **separating two overlapping audio sources** from a single-channel mixture using **time–frequency analysis and masking**, with **no machine learning or pretrained models**.

This project demonstrates that well-designed DSP heuristics can effectively separate sources occupying different frequency bands.

---

## 🎯 Problem Statement

In real-world audio recordings, multiple sound sources (e.g., speech and music) often overlap in time.
While modern solutions rely heavily on deep learning, this project focuses on a **fully interpretable, training-free DSP approach**.

### Objective

* Separate **two simultaneously active audio sources**
* Operate purely in the **time–frequency domain**
* Use **no neural networks, no prior training data**

---

## ✨ Key Features

* ✅ Pure DSP-based source separation (no ML)
* ✅ STFT / ISTFT based time–frequency analysis
* ✅ Harmonic–Percussive Source Separation (HPSS)-inspired energy estimation
* ✅ Adaptive frequency-band emphasis (speech-dominant band)
* ✅ Wiener-style soft time–frequency masking
* ✅ Smooth signal reconstruction using overlap–add
* ✅ Spectrogram and mask visualizations
* ✅ MATLAB implementation (research & competition friendly)

---

## 🧠 System Overview

```
Input Mixture
     ↓
STFT (Hann window, overlap)
     ↓
Power Spectrogram
     ↓
HPSS-based Energy Maps
     ↓
Adaptive Band Emphasis
     ↓
Soft Wiener Masks
     ↓
Masked STFTs
     ↓
Inverse STFT
     ↓
Separated Sources
```

The system exploits **spectral structure** and **frequency dominance** of sources rather than learning-based models.

---

## 📁 Project Structure

```
Audio_Source_Separation/
│
├── data/
│   └── mixed.wav                 # Input mixture audio
│
├── outputs/
│   ├── clean_1.wav               # Separated source 1
│   ├── clean_2.wav               # Separated source 2
│   ├── mixture_spectrogram.png   # Spectrogram of mixture
│   └── soft_masks.png            # Time–frequency masks
│
├── band_tracking.m               # Adaptive frequency-band tracking
├── config.m                      # Global configuration
├── hpss_energy_maps.m            # HPSS-inspired energy estimation
├── io_utils.m                    # Audio I/O utilities
├── main.m                        # Main pipeline
├── masking.m                     # Wiener-style soft masks
├── reconstruction.m              # ISTFT-based reconstruction
├── stft_utils.m                  # Unified STFT / ISTFT utilities
├── visualization.m               # Spectrogram & mask plots
│
└── report/
    └── source_separation_report.tex  # 5-page DSP report (LaTeX)
```

---

## ⚙️ Requirements

* MATLAB R2020a or later (recommended)
* No external ML libraries
* Uses standard MATLAB signal processing functions

> ⚠️ `hpss_energy_maps.m` uses `medfilt2` (Image Processing Toolbox).
> If unavailable, a pure-MATLAB fallback can be used.

---

## ▶️ How to Run

1. **Clone the repository**

   ```bash
   git clone https://github.com/your-username/audio-source-separation-dsp.git
   cd audio-source-separation-dsp
   ```

2. **Open MATLAB and add project path**

   ```matlab
   addpath(genpath(pwd))
   ```

3. **Run the main script**

   ```matlab
   main
   ```

4. **Outputs generated**

   * Separated audio files (`outputs/clean_1.wav`, `outputs/clean_2.wav`)
   * Spectrogram of mixture
   * Time–frequency soft masks

---

## 📊 Visual Outputs

* **Log-Magnitude Spectrogram**
  Shows frequency separation in the mixture

* **Soft Time–Frequency Masks**
  Visualizes dominance of each source over time and frequency

These plots help **justify separation quality qualitatively**.

---

## 📄 Technical Report

A detailed **5-page LaTeX report** is included in:

```
report/source_separation_report.tex
```

It covers:

* Signal model
* DSP methodology
* STFT analysis
* HPSS-based energy estimation
* Masking and reconstruction
* Experimental discussion

---

## 🚫 What This Project Does NOT Use

* ❌ Neural networks
* ❌ Deep learning
* ❌ Pretrained models
* ❌ Data-driven optimization

This is a **fully deterministic, explainable DSP solution**.

---

## 🚀 Future Extensions

* Quantitative evaluation using **SDR / SIR / SAR**
* Stereo and spatial source separation
* Adaptive band tracking across time
* Real-time or embedded DSP implementation

---

## 📜 License

This project is released for **educational and research purposes**.
Feel free to extend and adapt with proper attribution.

---

## 🙌 Acknowledgements

Inspired by classical DSP literature on:

* Time–frequency masking
* Wiener filtering
* Harmonic–percussive source separation

---
