function [source_1, source_2] = reconstruction(stft_matrix, mask_1, mask_2, sample_rate, cfg)
%RECONSTRUCT_SOURCES  Reconstruct time-domain sources from soft T–F masks
%
% Inputs:
%   stft_matrix : complex STFT of mixture (freq x time)
%   mask_1      : soft mask for source 1 (freq x time)
%   mask_2      : soft mask for source 2 (freq x time)
%   sample_rate : sampling rate (Hz)
%   cfg         : configuration struct
%
% Outputs:
%   source_1    : reconstructed time-domain signal (source 1)
%   source_2    : reconstructed time-domain signal (source 2)

    % ---------------- VALIDATION ----------------
    if ~isnumeric(stft_matrix) || ~any(imag(stft_matrix(:)) ~= 0)
        error('Input STFT matrix must be complex-valued');
    end

    if ~isequal(size(stft_matrix), size(mask_1)) || ...
       ~isequal(size(stft_matrix), size(mask_2))
        error('STFT matrix and masks must have the same dimensions');
    end

    % ---------------- MASK APPLICATION ----------------
    stft_source_1 = mask_1 .* stft_matrix;
    stft_source_2 = mask_2 .* stft_matrix;

    % ---------------- INVERSE STFT ----------------
    source_1 = stft_utils('istft', stft_source_1, sample_rate, cfg);
    source_2 = stft_utils('istft', stft_source_2, sample_rate, cfg);
end
