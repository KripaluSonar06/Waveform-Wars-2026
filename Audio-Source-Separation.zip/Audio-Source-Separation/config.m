function cfg = config()
%CONFIG  Configuration parameters for DSP-based audio source separation

cfg.SAMPLE_RATE  = 44100;   % Sampling rate of input audio (Hz)

% STFT parameters
cfg.FFT_SIZE     = 2048;    % Number of FFT points
cfg.HOP_LENGTH   = 512;     % Hop size (samples between frames)
cfg.WINDOW_TYPE  = 'hann';  % Window function type

% Masking parameters
cfg.MASK_EXPONENT = 1.0;    % Wiener mask exponent
cfg.EPSILON       = 1e-10;  % Numerical stability constant

end
