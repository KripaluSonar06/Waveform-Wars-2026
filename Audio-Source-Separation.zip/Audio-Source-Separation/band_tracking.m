function varargout = band_tracking(action, varargin)
%BAND_TRACKING  Adaptive frequency-band tracking utilities
%
% Usage:
%   y = band_tracking('smooth', spectrum, sigma)
%   [p1, p2] = band_tracking('find_peaks', spectrum)
%   [E1, E2] = band_tracking('estimate_maps', magnitude_spectrogram, sigma)

    switch lower(action)

        % ================= SPECTRUM SMOOTHING =================
        case 'smooth'
            spectrum = varargin{1};
            sigma    = varargin{2};

            if nargin < 3
                sigma = 2.0;
            end

            spectrum = spectrum(:);
            y = gaussian_smooth_1d(spectrum, sigma);
            varargout = {y};

        % ================= FIND 2 DOMINANT PEAKS =================
        case 'find_peaks'
            spectrum = varargin{1};
            spectrum = spectrum(:);

            [~, locs] = findpeaks(spectrum);

            if numel(locs) < 2
                mid = floor(numel(spectrum) / 2);
                [~, low_peak]  = max(spectrum(1:mid));
                [~, high_peak] = max(spectrum(mid+1:end));
                high_peak = high_peak + mid;
                varargout = {low_peak, high_peak};
                return;
            end

            [~, order] = sort(spectrum(locs), 'descend');
            peak1 = locs(order(1));
            peak2 = locs(order(2));

            peaks = sort([peak1, peak2]);
            varargout = {peaks(1), peaks(2)};

        % ================= ENERGY MAP ESTIMATION =================
        case 'estimate_maps'
            magnitude = varargin{1};

            if nargin < 3
                sigma = 2.0;
            else
                sigma = varargin{2};
            end

            if ndims(magnitude) ~= 2
                error('Input magnitude spectrogram must be 2-D');
            end

            [num_freqs, num_frames] = size(magnitude);

            E1 = zeros(num_freqs, num_frames);
            E2 = zeros(num_freqs, num_frames);

            freq_idx = (1:num_freqs).';

            for t = 1:num_frames
                spectrum = magnitude(:, t);
                smoothed = gaussian_smooth_1d(spectrum, sigma);

                [p_low, p_high] = band_tracking('find_peaks', smoothed);

                dist_low  = abs(freq_idx - p_low);
                dist_high = abs(freq_idx - p_high);

                mask_low  = dist_low <= dist_high;
                mask_high = ~mask_low;

                E1(mask_low,  t) = spectrum(mask_low);
                E2(mask_high, t) = spectrum(mask_high);
            end

            varargout = {E1, E2};

        otherwise
            error('Unknown band_tracking action: %s', action);
    end
end

% =====================================================================
% LOCAL GAUSSIAN SMOOTHING (PURE MATLAB, NO TOOLBOX)
% =====================================================================
function y = gaussian_smooth_1d(x, sigma)

    x = x(:);
    radius = ceil(3 * sigma);
    n = -radius:radius;

    g = exp(-(n.^2) / (2 * sigma^2));
    g = g / sum(g);

    y = conv(x, g, 'same');
end
