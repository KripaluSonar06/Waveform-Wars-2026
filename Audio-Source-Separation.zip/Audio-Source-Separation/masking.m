function [m1, m2] = masking(e1, e2, p, epsilon)
%COMPUTE_SOFT_MASKS  Wiener-style soft time–frequency masks for 2 sources
%
% Inputs:
%   e1      : energy map of source 1  (time x frequency)
%   e2      : energy map of source 2  (time x frequency)
%   p       : mask exponent (p > 0)
%   epsilon : small constant for numerical stability
%
% Outputs:
%   m1      : soft mask for source 1
%   m2      : soft mask for source 2

    if nargin < 3
        p = 1.0;
    end
    if nargin < 4
        epsilon = 1e-10;
    end

    % ---------------- VALIDATION ----------------
    if ~isequal(size(e1), size(e2))
        error('Energy maps e1 and e2 must have the same size');
    end

    if p <= 0
        error('Mask exponent p must be positive');
    end

    % ---------------- WIENER MASK ----------------
    e1_p = e1 .^ p;
    e2_p = e2 .^ p;

    denominator = e1_p + e2_p + epsilon;

    m1 = e1_p ./ denominator;
    m2 = e2_p ./ denominator;
end
