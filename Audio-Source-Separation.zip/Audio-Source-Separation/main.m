function main()
% MAIN  Audio Source Separation using Pure DSP

    fprintf("Audio Source Separation using Digital Signal Processing\n");

    % -------------------------------------------------
    % Add project folders to MATLAB path
    % -------------------------------------------------
    addpath(genpath(pwd));

    % ---------------- LOAD CONFIG ----------------
    cfg = config();

    % ---------------- LOAD MIXTURE ----------------
    fprintf("Loading mixture audio...\n");
    [mixture, sample_rate] = io_utils('load', 'data/mixed.wav');

    if sample_rate ~= cfg.SAMPLE_RATE
        fprintf("Warning: Input sample rate %d Hz differs from config %d Hz\n", ...
                sample_rate, cfg.SAMPLE_RATE);
    end

    % ---------------- STFT ----------------
    fprintf("Computing STFT...\n");
    [stft_matrix, ~, ~] = stft_utils('stft', mixture, sample_rate, cfg);
    magnitude = abs(stft_matrix);
    % ---- ISTFT sanity check (CRITICAL) ----
    test_recon = stft_utils('istft', stft_matrix, sample_rate, cfg);

    fprintf("ISTFT test: mean abs = %.6f\n", mean(abs(test_recon)));

    io_utils('save', 'outputs/istft_test.wav', test_recon, sample_rate);


    % ---------------- ENERGY MAP ESTIMATION ----------------
    fprintf("Estimating energy maps using HPSS...\n");
    [E_harm, E_perc] = hpss_energy_maps(magnitude);

    % ---------------- FREQUENCY AXIS ----------------
    freq_axis = linspace(0, sample_rate/2, size(magnitude,1));

    % Speech-dominant band emphasis (pure DSP heuristic)
    speech_band = (freq_axis >= 80) & (freq_axis <= 3500);

    % Apply band emphasis (correct MATLAB indexing)
    E_perc(speech_band, :) = 1.3 * E_perc(speech_band, :);
    E_harm(speech_band, :) = 0.8 * E_harm(speech_band, :);

    % ---------------- SOFT MASKS ----------------
    fprintf("Computing Wiener-style soft masks...\n");
    [m1, m2] = masking(E_harm, E_perc, cfg.MASK_EXPONENT, cfg.EPSILON);

    fprintf("Mask means: %.4f %.4f\n", mean(m1(:)), mean(m2(:)));
    fprintf("Mask stds : %.4f %.4f\n", std(m1(:)), std(m2(:)));

    fprintf("Mask min/max m1: %.6f %.6f\n", min(m1(:)), max(m1(:)));
    fprintf("Mask min/max m2: %.6f %.6f\n", min(m2(:)), max(m2(:)));


    % ---------------- RECONSTRUCTION ----------------
    fprintf("Reconstructing time-domain signals...\n");
    [source_1, source_2] = reconstruction( ...
        stft_matrix, m1, m2, sample_rate, cfg);

    %source_1 = source_1 / (max(abs(source_1)) + eps);
    %source_2 = source_2 / (max(abs(source_2)) + eps);

    % ---- RMS normalization (correct for DSP separation) ----
    target_rms = 0.05;   % good listening level

    source_1 = source_1 * (target_rms / (rms(source_1) + eps));
    source_2 = source_2 * (target_rms / (rms(source_2) + eps));

    fprintf("Source 1 RMS: %.6f\n", rms(source_1));
    fprintf("Source 2 RMS: %.6f\n", rms(source_2));

    % --- FORCE AMPLIFICATION (PROOF STEP) ---
    source_1_play = source_1 * 500;
    source_2_play = source_2 * 500;

    io_utils('save', 'outputs/clean_1_LOUD.wav', source_1_play, sample_rate);
    io_utils('save', 'outputs/clean_2_LOUD.wav', source_2_play, sample_rate);


    % ---------------- SAVE OUTPUTS ----------------
    fprintf("Saving separated audio files...\n");
    io_utils('save', 'outputs/clean_1.wav', source_1, sample_rate);
    io_utils('save', 'outputs/clean_2.wav', source_2, sample_rate);

    figure;
    subplot(2,1,1); plot(source_1); title('Source 1 waveform');
    subplot(2,1,2); plot(source_2); title('Source 2 waveform');


    % ---------------- VISUALIZATION ----------------
    fprintf("Generating visualizations...\n");

    visualization( ...
        'spectrogram', ...
        magnitude, sample_rate, cfg.HOP_LENGTH, ...
        'Mixture Log-Magnitude Spectrogram', ...
        'outputs/mixture_spectrogram.png');

    visualization( ...
        'masks', ...
        m1, m2, sample_rate, cfg.HOP_LENGTH, ...
        'Soft Mask of Source 1', ...
        'Soft Mask of Source 2', ...
        'outputs/soft_masks.png');

    fprintf("✔ 2 clean source signals separated successfully\n");
end
