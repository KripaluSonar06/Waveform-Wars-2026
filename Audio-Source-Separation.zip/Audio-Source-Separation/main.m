function main()
% MAIN  Audio Source Separation using Pure DSP

    fprintf("Audio Source Separation using Digital Signal Processing\n");

    % -------------------------------------------------
    % Add project folders to MATLAB path
    % -------------------------------------------------
    addpath(genpath(pwd));

    % ---------------- LOAD CONFIG ----------------
    cfg = config();

    % ---------------- LOAD MIXTURE ----------------
    fprintf("Loading mixture audio...\n");
    [mixture, sample_rate] = io_utils('load', 'data/mixed.wav');

    if sample_rate ~= cfg.SAMPLE_RATE
        fprintf("Warning: Input sample rate %d Hz differs from config %d Hz\n", ...
                sample_rate, cfg.SAMPLE_RATE);
    end

    % ---------------- STFT ----------------
    fprintf("Computing STFT...\n");
    [stft_matrix, ~, ~] = stft_utils('stft', mixture, sample_rate, cfg);
    magnitude = abs(stft_matrix);

    % ---------------- ENERGY MAP ESTIMATION ----------------
    fprintf("Estimating energy maps using HPSS...\n");
    [E_harm, E_perc] = hpss_energy_maps(magnitude);

    % ---------------- FREQUENCY AXIS ----------------
    freq_axis = linspace(0, sample_rate/2, size(magnitude,1));

    % Speech-dominant band emphasis (pure DSP heuristic)
    speech_band = (freq_axis >= 80) & (freq_axis <= 3500);

    % Apply band emphasis (correct MATLAB indexing)
    E_perc(speech_band, :) = 1.3 * E_perc(speech_band, :);
    E_harm(speech_band, :) = 0.8 * E_harm(speech_band, :);

    % ---------------- SOFT MASKS ----------------
    fprintf("Computing Wiener-style soft masks...\n");
    [m1, m2] = masking(E_harm, E_perc, cfg.MASK_EXPONENT, cfg.EPSILON);

    fprintf("Mask means: %.4f %.4f\n", mean(m1(:)), mean(m2(:)));
    fprintf("Mask stds : %.4f %.4f\n", std(m1(:)), std(m2(:)));

    % ---------------- RECONSTRUCTION ----------------
    fprintf("Reconstructing time-domain signals...\n");
    [source_1, source_2] = reconstruction( ...
        stft_matrix, m1, m2, sample_rate, cfg);

    % ---------------- SAVE OUTPUTS ----------------
    fprintf("Saving separated audio files...\n");
    io_utils('save', 'outputs/clean_1.wav', source_1, sample_rate);
    io_utils('save', 'outputs/clean_2.wav', source_2, sample_rate);

    % ---------------- VISUALIZATION ----------------
    fprintf("Generating visualizations...\n");

    visualization( ...
        'spectrogram', ...
        magnitude, sample_rate, cfg.HOP_LENGTH, ...
        'Mixture Log-Magnitude Spectrogram', ...
        'outputs/mixture_spectrogram.png');

    visualization( ...
        'masks', ...
        m1, m2, sample_rate, cfg.HOP_LENGTH, ...
        'Soft Mask of Source 1', ...
        'Soft Mask of Source 2', ...
        'outputs/soft_masks.png');

    fprintf("✔ 2 clean source signals separated successfully\n");
end
