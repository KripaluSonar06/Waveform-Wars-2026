function [harmonic, percussive] = hpss_energy_maps(magnitude, harm_kernel, perc_kernel)
%HPSS_ENERGY_MAPS  Compute harmonic and percussive energy maps
%
% Inputs:
%   magnitude    : STFT magnitude spectrogram (freq x time)
%   harm_kernel  : median filter length along frequency (default: 31)
%   perc_kernel  : median filter length along time (default: 31)
%
% Outputs:
%   harmonic     : harmonic energy map
%   percussive   : percussive energy map

    if nargin < 2
        harm_kernel = 31;
    end
    if nargin < 3
        perc_kernel = 31;
    end

    % ---------------- VALIDATION ----------------
    if ~isnumeric(magnitude)
        error('Input magnitude must be numeric');
    end

    % ---------------- POWER SPECTROGRAM ----------------
    %power = magnitude .^ 2;
    power = magnitude;


    % ---------------- MEDIAN FILTERING ----------------
    % Harmonic: median along frequency axis (horizontal structures)
    harmonic = medfilt2(power, [1, harm_kernel], 'symmetric');

    % Percussive: median along time axis (vertical structures)
    percussive = medfilt2(power, [perc_kernel, 1], 'symmetric');
end
