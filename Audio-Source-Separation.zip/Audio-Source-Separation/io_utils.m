function varargout = io_utils(action, varargin)
%IO_UTILS  Audio input/output utilities (single-file)
%
% Usage:
%   [signal, fs] = io_utils('load', path)
%   io_utils('save', path, signal, fs)

    switch lower(action)

        % ================= LOAD AUDIO =================
        case 'load'
            path = varargin{1};

            if ~isfile(path)
                error('Audio file not found: %s', path);
            end

            [signal, fs] = audioread(path);

            % Convert to mono if needed
            if size(signal, 2) > 1
                signal = mean(signal, 2);
            end

            signal = single(signal);

            varargout = {signal, fs};

        % ================= SAVE AUDIO =================
        case 'save'
            path        = varargin{1};
            signal      = varargin{2};
            sample_rate = varargin{3};

            if ~isvector(signal)
                error('Audio signal must be a 1-D vector');
            end

            audiowrite(path, signal(:), sample_rate);

        otherwise
            error('Unknown action "%s". Use "load" or "save".', action);
    end
end
