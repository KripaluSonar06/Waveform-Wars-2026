function varargout = stft_utils(action, varargin)
%STFT_UTILS  Unified STFT / ISTFT utility (single-file replacement)
%
% Usage:
%   [S, f, t] = stft_utils('stft', signal, sample_rate, cfg)
%   x         = stft_utils('istft', S, sample_rate, cfg)

    switch lower(action)

        % ================= STFT =================
        case 'stft'
            signal       = varargin{1};
            sample_rate  = varargin{2};
            cfg          = varargin{3};

            if ~isvector(signal)
                error('Audio signal must be a 1-D vector');
            end

            signal = signal(:);  % column vector
            window = local_window(cfg.WINDOW_TYPE, cfg.FFT_SIZE);

            [S, f, t] = stft( ...
                signal, ...
                sample_rate, ...
                'Window', window, ...
                'FFTLength', cfg.FFT_SIZE, ...
                'OverlapLength', cfg.FFT_SIZE - cfg.HOP_LENGTH, ...
                'FrequencyRange', 'onesided' ...
            );

            varargout = {S, f, t};

        % ================= ISTFT =================
        case 'istft'
            S            = varargin{1};
            sample_rate  = varargin{2};
            cfg          = varargin{3};

            if ~isnumeric(S)
                error('STFT matrix must be numeric and complex-valued');
            end

            window = local_window(cfg.WINDOW_TYPE, cfg.FFT_SIZE);

            x = istft( ...
                S, ...
                sample_rate, ...
                'Window', window, ...
                'FFTLength', cfg.FFT_SIZE, ...
                'OverlapLength', cfg.FFT_SIZE - cfg.HOP_LENGTH, ...
                'FrequencyRange', 'onesided', ...
                'ConjugateSymmetric', true ...
            );

            varargout = {x};

        otherwise
            error('Unknown action "%s". Use "stft" or "istft".', action);
    end
end

% =====================================================================
% LOCAL WINDOW HELPER (kept inside same file)
% =====================================================================
function w = local_window(window_type, fft_size)

    switch lower(window_type)
        case 'hann'
            w = hann(fft_size, 'periodic');
        case 'hamming'
            w = hamming(fft_size, 'periodic');
        case 'blackman'
            w = blackman(fft_size, 'periodic');
        otherwise
            error('Unsupported window type: %s', window_type);
    end
end
