function visualization(action, varargin)
%VISUALIZATION  Spectrogram and mask visualization utilities
%
% Usage:
%   visualization('spectrogram', magnitude, fs, hop_length, title, output_path)
%   visualization('masks', mask1, mask2, fs, hop_length, title1, title2, output_path)

    switch lower(action)

        % ================= SPECTROGRAM =================
        case 'spectrogram'
            magnitude    = varargin{1};
            sample_rate  = varargin{2};
            hop_length   = varargin{3};
            plot_title   = varargin{4};
            output_path  = varargin{5};

            % Log-magnitude (dB)
            log_magnitude = 20 * log10(magnitude + 1e-10);

            [num_freqs, num_frames] = size(magnitude);

            time_axis = (0:num_frames-1) * hop_length / sample_rate;
            freq_axis = linspace(0, sample_rate/2, num_freqs);

            figure('Position',[100 100 1000 400]);
            imagesc(time_axis, freq_axis, log_magnitude);
            axis xy;
            colormap(parula);
            colorbar;
            xlabel('Time (s)');
            ylabel('Frequency (Hz)');
            title(plot_title);

            set(gca,'FontSize',10);
            %tightfig();

            exportgraphics(gcf, output_path, 'Resolution', 300);
            close(gcf);

        % ================= MASKS =================
        case 'masks'
            mask1       = varargin{1};
            mask2       = varargin{2};
            sample_rate = varargin{3};
            hop_length  = varargin{4};
            title1      = varargin{5};
            title2      = varargin{6};
            output_path = varargin{7};

            [num_freqs, num_frames] = size(mask1);

            time_axis = (0:num_frames-1) * hop_length / sample_rate;
            freq_axis = linspace(0, sample_rate/2, num_freqs);

            figure('Position',[100 100 1000 600]);

            subplot(2,1,1);
            imagesc(time_axis, freq_axis, mask1);
            axis xy;
            colormap(parula);
            colorbar;
            title(title1);
            ylabel('Frequency (Hz)');

            subplot(2,1,2);
            imagesc(time_axis, freq_axis, mask2);
            axis xy;
            colormap(parula);
            colorbar;
            title(title2);
            xlabel('Time (s)');
            ylabel('Frequency (Hz)');

            set(gcf,'Color','w');
            %tightfig();

            exportgraphics(gcf, output_path, 'Resolution', 300);
            close(gcf);

        otherwise
            error('Unknown visualization action: %s', action);
    end
end
